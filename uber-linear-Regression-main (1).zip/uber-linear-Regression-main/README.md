In this project, I predicted a uber fare_amount using ml pipeline and linear regression model.
